<template>
  <div id="app">
    <nav>
      <ul>
        <li><router-link to="/">Home</router-link></li>
        <li><router-link to="/racas">Raças</router-link></li>
        <li><router-link to="/cuidados">Cuidados</router-link></li>
        <li><router-link to="/galeria">Galeria</router-link></li>
      </ul>
    </nav>
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App',
};
</script>

<style>
nav ul {
  list-style: none;
  display: flex;
  justify-content: space-around;
  padding: 0;
  margin: 0;
}

nav li {
  padding: 15px 30px; 
}

nav a {
  text-decoration: none;
  color: #ff6347;
  font-size: 1.6rem; 
  font-weight: bold; 
  padding: 10px 20px; 
  border-radius: 5px; 
  transition: background-color 0.3s; 
}

nav a:hover {
  background-color: #ff6347; 
  color: white; 
}
</style>
