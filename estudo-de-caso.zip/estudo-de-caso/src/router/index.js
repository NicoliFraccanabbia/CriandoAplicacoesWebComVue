import { createRouter, createWebHistory } from 'vue-router';
import HomePage from '../components/HomePage.vue';
import RacasGatos from '../components/RacasGatos.vue';
import CuidadosGatos from '../components/CuidadosGatos.vue';
import GaleriaGatos from '../components/GaleriaGatos.vue';

const routes = [
  { path: '/', component: HomePage },
  { path: '/racas', component: RacasGatos },
  { path: '/cuidados', component: CuidadosGatos },
  { path: '/galeria', component: GaleriaGatos },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
