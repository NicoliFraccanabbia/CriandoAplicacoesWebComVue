<template>
  <div class="home">
    <h1>Bem-vindo ao Mundo dos Gatos!</h1>
    <p>Descubra tudo sobre os gatos: raças, cuidados e muito mais.</p>
    <img src="@/assets/images/gatos.jpg" alt="Gatos" class="cat-image" />
  </div>
</template>

<script>
export default {
  name: 'HomePage',
};
</script>

<style scoped>
.home {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100vh; 
  background-color: #f5f5f5; 
  color: #333; 
}

h1 {
  color: #ff6347; 
  font-size: 3rem;
}

p {
  color: #555; 
  font-size: 1.5rem;
}

.cat-image {
  width: 900px; 
  height: auto; 
  margin-top: 20px; 
  border-radius: 8px;
}
</style>