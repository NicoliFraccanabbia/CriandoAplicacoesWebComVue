<template>
  <div class="galeria">
    <h1>Galeria de Gatos</h1>
    <div class="gallery">
      <img src="@/assets/images/persa.jpg" alt="Gato Persa" class="gallery-image" />
      <img src="@/assets/images/siames.jpg" alt="Gato Siamês" class="gallery-image" />
      <img src="@/assets/images/maine-coon.jpg" alt="Gato Maine Coon" class="gallery-image" />
      <img src="@/assets/images/bengal.jpg" alt="Gato Maine Coon" class="gallery-image" />
      <img src="@/assets/images/abissinio.jpg" alt="Gato Maine Coon" class="gallery-image" />


    </div>
  </div>
</template>

<script>
export default {
  name: 'GaleriaGatos',
};
</script>

<style scoped>
.galeria {
  text-align: center;
  background-color: #f5f5f5;
  padding: 20px;
}

h1 {
  color: #ff6347;
  font-size: 2.5rem;
  margin-bottom: 20px;
}

.gallery {
  display: flex;
  justify-content: center;
  gap: 20px;
  flex-wrap: wrap; 
  margin-top: 20px;
}

.gallery-image {
  width: 300px;
  height: 200px;
  object-fit: cover; 
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}
</style>
