<template>
  <div class="cuidados">
    <h1>Cuidados com os Gatos</h1>
    <ul>
      <li>
        <img src="@/assets/images/alimentacao.jpg" alt="Alimentação Balanceada" class="cuidados-image" />
        <span>Alimentação balanceada</span>
      </li>
      <li>
        <img src="@/assets/images/veterinario.jpg" alt="Visitas ao Veterinário" class="cuidados-image" />
        <span>Visitas regulares ao veterinário</span>
      </li>
      <li>
        <img src="@/assets/images/brincadeiras.jpg" alt="Brincadeiras e Exercícios" class="cuidados-image" />
        <span>Brincadeiras e exercícios</span>
      </li>
      <li>
        <img src="@/assets/images/pelos-unhas.jpg" alt="Cuidados com o Pelo e Unhas" class="cuidados-image" />
        <span>Cuidados com o pelo e unhas</span>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'CuidadosGatos',
};
</script>

<style scoped>
.cuidados {
  text-align: center;
  background-color: #f5f5f5;
  padding: 20px;
}

h1 {
  color: #ff6347;
  font-size: 2.5rem;
  margin-bottom: 20px;
}

ul {
  list-style-type: none;
  padding: 0;
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
}

li {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin: 20px;
  padding: 15px;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  width: 250px; 
}

.cuidados-image {
  width: 150px; 
  height: 150px; 
  border-radius: 50%; 
  margin-bottom: 15px; 
}

span {
  font-size: 1.5rem;
  color: #333;
  text-align: center;
}
</style>
