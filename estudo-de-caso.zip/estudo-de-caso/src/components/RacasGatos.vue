<template>
  <div class="racas">
    <h1>Raças de Gatos</h1>
    <ul>
      <li v-for="(raca, index) in racas" :key="index" class="raca-item">
        <h2>{{ raca.nome }}</h2>
        <img :src="raca.imagem" :alt="raca.nome" class="raca-image" />
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'RacasGatos',
  data() {
    return {
      racas: [
        { nome: 'Persa', imagem: require('@/assets/images/persa.jpg') },
        { nome: 'Siamês', imagem: require('@/assets/images/siames.jpg') },
        { nome: 'Maine Coon', imagem: require('@/assets/images/maine-coon.jpg') },
        { nome: 'Abissínio', imagem: require('@/assets/images/abissinio.jpg') },
        { nome: 'Bengal', imagem: require('@/assets/images/bengal.jpg') },
      ]
    };
  }
};
</script>

<style scoped>
.racas {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background-color: #f5f5f5;
  color: #333;
  padding: 20px;
}

h1 {
  color: #ff6347;
  font-size: 2.5rem;
  margin-bottom: 20px;
}

ul {
  display: grid; 
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); 
  gap: 20px; 
  list-style-type: none;
  padding: 0;
}

.raca-item {
  text-align: center;
  background-color: #fff;
  border-radius: 8px;
  padding: 10px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.raca-item h2 {
  font-size: 1.8rem;
  color: #555;
}

.raca-image {
  width: 100%; 
  height: auto;
  border-radius: 8px;
}
</style>
